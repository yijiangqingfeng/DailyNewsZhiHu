package com.example.dailynews_zhihu;


import okhttp3.OkHttpClient;

public class Client {
    private static OkHttpClient instance;
    private Client(){
    }
    public static OkHttpClient getInstance(){
        if (instance == null){
            instance = new OkHttpClient.Builder().build(); // 这一行为核心代码
        }
        return instance;
    }
}
