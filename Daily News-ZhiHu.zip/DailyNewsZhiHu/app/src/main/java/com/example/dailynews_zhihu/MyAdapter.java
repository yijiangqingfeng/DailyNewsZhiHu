package com.example.dailynews_zhihu;

import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.gson.Gson;

import java.io.IOException;
import java.util.List;

import okhttp3.Call;
import okhttp3.Request;
import okhttp3.Response;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyViewHolder>{
    Handler handler = new Handler();
    ItemBean.StoriesBean bean;
    MyViewHolder holder;
    // 要在Item上显示的数据
    List<ItemBean.StoriesBean> mDataSet ;
    Context mContext;
    public MyAdapter(List data,Context context){
        this.mDataSet = data;
        this.mContext=context;
    }
    // 用于获取ViewHolder
    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        holder=new MyViewHolder(LayoutInflater.from(mContext).inflate(R.layout.info_item,parent,false));
//        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.info_item, parent, false);
//        MyViewHolder ViewHolder = new MyViewHolder(view);
        return holder;
    }
    public String getSearchInfo(){
        Request request = new Request.Builder()
                .url("http://news-at.zhihu.com/api/4/news/latest") // 填写请求的网址 url = "http://news-at.zhihu.com/api/4/news/latest"
                .get() // 使用get请求
                .build(); // 创建实例

        final Call call = Client.getInstance().newCall(request);
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Response response = call.execute();
                    String result = response.body().string();
                    Message message = Message.obtain();
                    message.what = 1;
                    message.obj = result;
                    handler.sendMessage(message);
                    Gson gson = new Gson();
                    ItemBean.StoriesBean bean = gson.fromJson(message.obj.toString(), ItemBean.StoriesBean.class);
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }
        }).start();
        return bean.getUrl();
    }
    // 将数据与ViewHolder绑定
    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        MyViewHolder mHolder= (MyViewHolder) holder;
//        ItemBean itemBean=mDataSet.get(position);
//        mHolder.textView.setText(itemBean.getText());
        holder.title.setText(mDataSet.get(position).getTitle());
        Glide.with(mContext).load(mDataSet.get(position).getUrl()).into(holder.img);
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(mContext,Main2Activity.class);
                mContext.startActivity(intent);
            }
        });
    }
    // 获取Item的数量
    @Override
    public int getItemCount() {
        return mDataSet.size();
    }

    // 以下五个方法是我自定义的，用来对数据进行一系列操作
//    public void refreshItems(List<ItemBean> items) {
//        mDataSet.clear();
//        mDataSet.addAll(items);
//        notifyDataSetChanged();
//    }

//    public void addItems(List<ItemBean> items) {
//        mDataSet.addAll(items);
//    }
//    public void addItem(ItemBean item){
//        mDataSet.add(item);
//    }
    public void deleteItem(int position) {
        mDataSet.remove(position);
        notifyItemRemoved(position);
        notifyItemRangeChanged(0, mDataSet.size() - 1);
    }

    // ViewHolder用于获取Item上的控件
    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView textView,title;
        ImageView img;
        public MyViewHolder(View itemView) {
            super(itemView);
            textView=(TextView) itemView.findViewById(R.id.item_headtitle);
            title=(TextView)itemView.findViewById(R.id.item_title);
            img =(ImageView)itemView.findViewById(R.id.item_image);
        }
    }
}
