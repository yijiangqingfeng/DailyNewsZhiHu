package com.example.dailynews_zhihu;

import android.os.Bundle;
import android.os.Handler;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity{
    RecyclerView recyclerView;//用于显示的列表

    ArrayList<ItemBean.StoriesBean> mDatas;//用于储存数据

    MyAdapter adapter;//适配器
    RecyclerView.LayoutManager layoutManager;
    TextView responseText;
    Handler handler = new Handler();
    ItemBean bean = new ItemBean();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initDate();
        initView();
//        recyclerView=(RecyclerView) findViewById(R.id.id_recycler);
//        //设置LayoutManager为LinearLayoutManager
//        layoutManager= new LinearLayoutManager(this);
//
//        //设置LayoutManager和Adapter
//        recyclerView.setLayoutManager(layoutManager);
//        recyclerView.setAdapter(adapter);
//        Request request = new Request.Builder()
//                .url("http://news-at.zhihu.com/api/4/news/latest") // 填写请求的网址 url = "http://news-at.zhihu.com/api/4/news/latest"
//                .get() // 使用get请求
//                .build(); // 创建实例
//
//        final Call call = Client.getInstance().newCall(request);
//        new Thread(new Runnable() {
//            @Override
//            public void run() {
//                try {
//                    Response response = call.execute();
//                    String result = response.body().string();
//                    Message message = Message.obtain();
//                    message.what = 1;
//                    message.obj = result;
//                    handler.sendMessage(message);
//                    Gson gson = new Gson();
//                    bean = gson.fromJson(message.obj.toString(), ItemBean.class);
//
//                } catch (IOException e) {
//                    e.printStackTrace();
//                }
//
//            }
//        }).start();
//
//        for(int i=0;i<5;i++){
//            ItemBean itemBean=new ItemBean();
//            itemBean.setText(bean.getStories().get(i).getTitle());
//            itemBean.setText("i");
//            adapter.addItem(itemBean);
//        }

    }
//    @Override
//    public void onClick(View v) {
//        if(v.getId() == R.id.tv_text){
//            sendRequestWithOkhttp();
//        }
//    }
//    public void sendRequestWithOkhttp(){
//        new Thread(new Runnable() {
//            @Override
//            public void run() {
//                try{
//                    OkHttpClient client = new OkHttpClient();
//                    Request request = new Request.Builder()
//                            .url("http://news-at.zhihu.com/api/4/news/latest")
//                            .build();
//                    Response response = client.newCall(request).execute();
//                    String responseData = response.body().string();
//                    showResponse(responseData);
//                }catch (Exception e){
//                    e.printStackTrace();
//                }
//            }
//        }).start();
//    }
//    private void showResponse(final String response){
//        runOnUiThread(new Runnable() {
//            @Override
//            public void run() {
//                //在这里进行UI操作，将结果显示到界面上
//                responseText.setText(response);
//            }
//        });
//    }
    private void initView() {
        //初始化页面
//        setTitle("首页", 1);//设置标题
        recyclerView= (RecyclerView) findViewById(R.id.id_recycler);//绑定RecycleView
        recyclerView.setLayoutManager(new LinearLayoutManager(this));//设置布局管理器，你可以通过这个来决定你是要做一个Listview还是瀑布流
        adapter=new MyAdapter(mDatas,MainActivity.this);//初始化适配器
        recyclerView.setAdapter(adapter);//为ReycleView设置适配器

    }
    private void  initDate(){
        //初始化数据
        mDatas=new ArrayList<>();

        //添加模拟数据
        for (int i='A';i<'z';i++){
            ItemBean.StoriesBean item=new ItemBean.StoriesBean();
            item.setTitle(""+(char)i);
            item.setUrl("https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1496110531&di=281ed2731cabceee7c851e5b2ca83a85&imgtype=jpg&er=1&src=http%3A%2F%2Fpic.58pic.com%2F58pic%2F13%2F15%2F64%2F44c58PICsni_1024.jpg");
            mDatas.add(item);
        }


    }
}
